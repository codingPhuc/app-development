1. Chạy lệnh 'npm install' để tải lại các module mà project đang dùng
2. Chạy npm start để khởi động web server
3. Truy cập http://localhost:8080 để xem kết quả
